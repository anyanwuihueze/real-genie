
// This file is no longer used for the header logo and can be deleted or kept for other purposes.
// Its content is blanked to reflect its removal from active use in the header.
import type { SVGProps } from 'react';

export function PlaneOnRunwayLogoIcon(props: SVGProps<SVGSVGElement>) {
  return (
    <svg
      // Empty SVG or a comment indicating it's deprecated for header use
      {...props}
    ></svg>
  );
}
