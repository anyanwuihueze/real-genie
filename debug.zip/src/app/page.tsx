export default function Home() { return <h1>Fixed!</h1>; }
